"""R15: tre sedi passive, culle a U bilaterali e coperchio a due agganci."""
from pathlib import Path
import json,hashlib,importlib.metadata
import cadquery as cq
import numpy as np
import trimesh

ROOT=Path(__file__).resolve().parents[1]
P=json.loads((ROOT/"sorgenti/parametri.json").read_text())
W,D,B=P["larghezza"],P["profondita"],P["base"]
Z=P["quota_seduta"];TOP=P["quota_tetto"];S=P["slot"]


def box(x,y,z,dx,dy,dz):return cq.Solid.makeBox(dx,dy,dz,cq.Vector(x,y,z))
def cylinder(x,y,z,r,h):return cq.Solid.makeCylinder(r,h,cq.Vector(x,y,z))
def union(shapes):return shapes[0].fuse(*shapes[1:]).clean() if len(shapes)>1 else shapes[0]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
def bounds(shape):
    b=shape.BoundingBox()
    return [[b.xmin,b.ymin,b.zmin],[b.xmax,b.ymax,b.zmax]]
def rounded(x,y,z,dx,dy,dz,r):
    if r<=0:return box(x,y,z,dx,dy,dz)
    return cq.Workplane("XY").box(dx,dy,dz,centered=False).edges("|Z").fillet(r).val().translate((x,y,z))
def mesh_of(shape):
    vs,fs=shape.tessellate(.045,.09)
    return trimesh.Trimesh(np.array([v.toTuple() for v in vs]),np.array(fs),process=True)
def outer_fillet(shape,z,r):
    if r<=0:return shape
    edges=[]
    for e in shape.Edges():
        b=e.BoundingBox()
        if abs(b.zmin-z)<1e-5 and abs(b.zmax-z)<1e-5 and min(abs(b.xmin),abs(b.xmax-W),abs(b.ymin),abs(b.ymax-D))<1e-5:
            edges.append(e)
    return shape.Solids()[0].fillet(r,edges).clean()
def profile(points,y,width):
    wire=cq.Wire.makePolygon([cq.Vector(x,y,z) for x,z in points],close=True)
    return cq.Solid.extrudeLinear(wire,[],cq.Vector(0,width,0))
def left(slot=0):return S["primo_centro_x"]+slot*S["passo"]-S["larghezza_libera"]/2
def right(slot=0):return left(slot)+S["larghezza_libera"]


def saddle(y,slot=0):
    lo,hi=left(slot),right(slot);t=S["spessore_guide"];dy=S["larghezza_appoggio_y"]
    riser=box(lo-t,y-dy/2,0,S["larghezza_libera"]+2*t,dy,Z)
    fins=[]
    for x in (lo-t,hi):
        fin=box(x,y-dy/2,Z,t,dy,S["altezza_guide"])
        edges=[e for e in fin.Edges() if abs(e.BoundingBox().zmin-31)<1e-6 and abs(e.BoundingBox().zmax-31)<1e-6]
        fins.append(fin.fillet(.25,edges))
    shape=union([riser,*fins])
    # Piccola cava sull'esterno della guida destra: trattiene solo l'inserto.
    return shape.cut(box(hi+t-.35,y-dy/2-.1,21.4,.5,dy+.2,1.4)).clean()


def front_stop(slot=0):
    return box(left(slot),13.5,0,S["larghezza_libera"],2,20)


def drive_seat_z(model):
    return Z + (P["supporti_u"]["spessore_base_mm"] if model != "T9" else 0)


def adapter(model,y=36,slot=0):
    """Culla a U bilaterale: due collari e base comune, calzata sulle guide R14.

    Le sponde sono intere davanti/dietro la guida; nessuna lamina sottile
    fra Shield e guida. Il ponte inferiore appoggia sulla seduta esistente.
    """
    assert model in ("T7","T7_Shield")
    u=P["supporti_u"];cx=(left(slot)+right(slot))/2
    ext=u["larghezza_esterna_mm"];depth=u["profondita_mm"]
    floor=u["spessore_base_mm"];height=u["altezza_sponde_mm"]
    gap=u["gioco_guide_per_lato_mm"];opening=S["larghezze_adattate"][model]
    band=S["larghezza_appoggio_y"]+2*gap
    end_depth=(depth-band)/2;wall=(ext-opening)/2
    bridge=box(left(slot)+gap,y-depth/2,Z,S["larghezza_libera"]-2*gap,depth,floor)
    members=[bridge]
    for yy in (y-depth/2,y+band/2):
        members += [box(cx-ext/2,yy,Z,ext,end_depth,floor),
            box(cx-ext/2,yy,Z+floor,wall,end_depth,height),
            box(cx+opening/2,yy,Z+floor,wall,end_depth,height)]
    return union(members)


def vent_holes(z,height):
    v=P["ventilazione"];length=(v["lunghezza_campo"]-v["spina"])/2
    offset=(length+v["spina"])/2
    return [cq.Workplane("XY").slot2D(length,v["larghezza"]).extrude(height).val().translate((45+dx,y,z))
            for y in v["centri_y"] for dx in (-offset,offset)]


def side_pattern_points():
    p=P["pattern_laterale"];points=[]
    for row in range(12):
        base_z=p["primo_z"]+row*p["passo_z"]
        offset=p["passo_y"]/2 if p["righe_sfalsate"] and row%2 else 0
        for column in range(18):
            y=p["primo_y"]+offset+column*p["passo_y"]
            z=base_z+p["inclinazione_righe"]*(y-p["y_min"])
            half_w,half_h=p["larghezza"]/2,p["altezza"]/2
            if y-half_w<p["y_min"] or y+half_w>p["y_max"]:continue
            low=p["z_min"]+p["inclinazione_bordi"]*(y-p["y_min"])
            high=p["z_max"]+p["inclinazione_bordi"]*(y-p["y_min"])
            if z-half_h<low or z+half_h>high:continue
            middle=p["diagonale_z_a_y_min"]+p["pendenza_diagonale"]*(y-p["y_min"])
            extent=abs(p["pendenza_diagonale"])*half_w+half_h
            distance=p["fascia_diagonale_mm"]/2*(1+p["pendenza_diagonale"]**2)**.5
            if abs(z-middle)<distance+extent:continue
            points.append((float(y),float(z)))
    return points


def side_pattern_holes():
    p=P["pattern_laterale"]
    return [cq.Workplane("YZ").slot2D(p["larghezza"],p["altezza"],p["angolo_feritoia_gradi"]).extrude(3.4).val().translate((x,y,z))
            for x in (-.2,W-3.2) for y,z in side_pattern_points()]


def logo_relief_shapes():
    p=P["logo_frontale"];data=json.loads((ROOT/"sorgenti"/p["sorgente"]).read_text())
    assert data["glyphs"]==2 and data["name"]=="logo_S9" and not p["sottotitolo"]
    assert sha(ROOT/data["source_png"])==data["source_png_sha256"]
    assert sha(ROOT/data["vector_svg"])==data["vector_svg_sha256"]
    scale=p["larghezza_mm"];x=W-p["margine_destro_mm"]-scale;z=p["margine_inferiore_mm"]
    y=p["sovrapposizione_mm"];depth=p["rilievo_mm"]+y
    def wire(points):
        return cq.Wire.makePolygon([cq.Vector(x+u*scale,y,z+v*scale) for u,v in points],close=True)
    return [cq.Solid.extrudeLinear(wire(s["outer"]),[wire(h) for h in s["holes"]],cq.Vector(0,-depth,0)) for s in data["shapes"]]


def shell():
    outer=rounded(0,0,0,W,D,TOP,P["raggio_esterno"])
    outer=outer_fillet(outer,0,P["raccordo_bordi"])
    inner=rounded(3,3,B,W-6,D-6,TOP,1.2)
    shape=outer.cut(inner)
    cuts=vent_holes(-1,B+1.01)
    cuts += [box(3,D-4,B,W-6,6,TOP)]
    for x in (-.2,W-3.2):
        cuts.append(box(x,45.7,71,3.4,9.6,3))
    cuts += side_pattern_holes()
    shape=shape.cut(*cuts)
    shapes=[shape]
    for slot in range(3):
        shapes += [saddle(y,slot) for y in S["centri_y"]]
        shapes += [front_stop(slot)]
    for x,y in P["piedini"]["centri_xy"]:
        shapes.append(cylinder(x,y,0,P["piedini"]["piazzole_diametro"]/2,B))
    shape=union(shapes)
    holes=[cylinder(x,y,-.1,P["piedini"]["sedi_diametro"]/2,P["piedini"]["sedi_profondita"]+.1)
           for x,y in P["piedini"]["centri_xy"]]
    shape=shape.cut(*holes).clean()
    return union([shape,*logo_relief_shapes()])


def lid_latch(side,loaded=False):
    """Forma libera stampata con pattino di precarico. loaded e solo un
    inviluppo traslato verso interno per il controllo statico, non una FEA.
    """
    c=P["coperchio"];x=3+c["gioco_laterale"];width=c["larghezza_linguetta"]
    yy=50.5-width/2
    finger=box(x,yy,TOP-c["lunghezza_linguetta"],c["spessore_linguetta"],width,c["lunghezza_linguetta"])
    tooth=profile([(3.4,72.0),(2.4,73.0),(3.4,74.0)],yy,width)
    low,high=c["pattino_z_min_mm"],c["pattino_z_max_mm"];r=c["pattino_rampa_mm"]
    reach=3-c["precarico_per_lato_mm"]
    pad=profile([(x+.1,low),(reach,low+r),(reach,high-r),(x+.1,high)],yy,width)
    result=union([finger,tooth,pad])
    if loaded:result=result.translate((c["precarico_per_lato_mm"],0,0))
    return result if side=="left" else result.mirror("YZ",(45,0,0))


def lid(loaded=False):
    rear=P['retro_coperchio'];rear_depth=D+rear['arretramento_esterno_mm']
    shape=rounded(0,0,TOP,W,rear_depth,3,P["raggio_esterno"])
    shape=outer_fillet(shape,TOP+3,P["raccordo_tetto_superiore"])
    shape=outer_fillet(shape,TOP,P["raccordo_tetto_inferiore"])
    shape=shape.cut(*vent_holes(TOP-1,5)).clean()
    locators=[box(x,3.3,80,8,1.6,3) for x in (19,63)]
    z=rear['quota_inferiore_mm'];t=rear['spessore_mm'];gap=rear['gioco_con_scocca_mm']
    tail=box(0,rear_depth-t,z,W,t,TOP-z)
    cheeks=[box(x,D+gap,z,t,rear['arretramento_esterno_mm']-t-gap,TOP-z) for x in (0,W-t)]
    return union([shape,lid_latch("left",loaded),lid_latch("right",loaded),*locators,tail,*cheeks])


def drive(model,slot=0,dz=0):
    d=P["ssd_nominali"][model]
    width=S["larghezze_adattate"][model]
    x=(left(slot)+right(slot)-d["spessore"])/2
    return box(x,S["inizio_ssd_y"],drive_seat_z(model)+dz,d["spessore"],d["lunghezza"],d["altezza"])


def usb_keepout(model,slot=0):
    """Ingombro prudenziale parametrico, non un modello misurato dello spinotto."""
    d=P['ssd_nominali'][model];r=P['retro_coperchio']
    center_x=(left(slot)+right(slot))/2
    center_z=drive_seat_z(model)+d['altezza']/2
    return box(center_x-r['ingombro_spina_larghezza_mm']/2,S['inizio_ssd_y']+d['lunghezza'],
        center_z-r['ingombro_spina_altezza_mm']/2,r['ingombro_spina_larghezza_mm'],r['lunghezza_rigida_cavo_mm'],r['ingombro_spina_altezza_mm'])
